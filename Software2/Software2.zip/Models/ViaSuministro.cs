﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Software2.Models
{
    public enum ViaSuministro
    {
        Oral,
        Tópica,
        Intramuscular,
        Intravenosa,
        BloqueParaLamer,
        Parental,
        Subcutánea,
        Rectal,
        Inhalatoria,
        Intranasal,
        Transdermica,
        Ótica,
        Oftálmica,
        Sublingual       
    }
}